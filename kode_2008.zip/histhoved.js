

/*

Dersom nye historiske lag skal legges til i kartløsningen  må de legges til som et eget sublayer fra norkart-WMS'en i WebMap'et. 
Lagnavnet må slutte på årstallet, slik at årstallet blir navnet på laget i drop-up menyen hvor årstall velges.

Rekkefølgen på wms-lagene som er brukt i AGOL WebMapet gjenspeiles i denne kartløsningen.  Stedsnavn-laget fra Kartverkets WMS fkb4 må ligge på toppen av innholdslisten i webmapet.

*/



var IEbrowser=( !!window.ActiveXObject && +( /msie\s(\d+)/i.exec( navigator.userAgent )[1] ) );

if (IEbrowser <= 11 || IEbrowser >= 7) {
  alert("Vennligst benytt en annen nettleser enn Internet Explorer som f.eks Google Chrome, Opera, Mozilla Firefox eller Safari.")
};

$( document ).ready( function () {

  //sett bakgrunnen til noe gjennomsiktig svart. 
  $(".velkommen").css("background-color", "rgba(0,0,0,0.5)")
  
  //Skjuler velkomstmeldingen dersom X-en trykkes
  $(".close").click( function () { 
    $(".velkommen").hide();
  });

  //Dersom knappen "Ikke vis igjen" har blitt trykket tidligere, så skjul velkomstmeldingen
  if(localStorage.getItem("IkkeVis")) {
    $(".velkommen").hide();
  }
  //Når "Ikke vis igjen"-knappen blir trykket, skjul velkomstmeldingen og sett "IkkeVis"-verdien i LocalStorage til "true".
  $(document).on("click", "#ikkevis", function() {
      localStorage.setItem("IkkeVis", "true");
      $(".velkommen").hide();
  });

});



//Last inn modulene som trengs til kartapplikasjonen    
require([
  "esri/map", 
  "esri/dijit/LayerSwipe",
  "esri/layers/layer",
  "esri/arcgis/utils",
  "dojo/_base/array",
  "esri/dijit/HomeButton",
  "esri/dijit/Search",
  "esri/layers/FeatureLayer",
  "esri/layers/ArcGISTiledMapServiceLayer",
  "dojo/domReady!"
], function(
  Map, LayerSwipe, layer, arcgisUtils, array, HomeButton, Search, FeatureLayer, ArcGISTiledMapServiceLayer
)  {
  var WebMapID = "604b8670fb8c4ce6be5d2ab0e85eabb6";
  var mapDeferred = arcgisUtils.createMap(WebMapID, "map");
  mapDeferred.then(function(response){
    var map = response.map;


  

    //var ingenbilder = new FeatureLayer("https://services.arcgis.com/43oQDcO8lvhTZSOO/arcgis/rest/services/ingenbilder70/FeatureServer/0");
    //map.addLayer(ingenbilder);


    var ingenbilder = new ArcGISTiledMapServiceLayer("https://tiles.arcgis.com/tiles/43oQDcO8lvhTZSOO/arcgis/rest/services/noimages20/MapServer");
    map.addLayer(ingenbilder);


    

    //console.log(map.getLayersVisibleAtScale());
    console.log(map.getLayer());
    ingenbilder.hide();
    map.reorderLayer(ingenbilder, 1);

    //console.log(map.getLayersVisibleAtScale());

    console.log(map.graphics);

    //Lager en Array av objekter med hvert kartlag. 
    var layers = response.itemInfo.itemData.operationalLayers;
    layers.reverse();
    var sisteLE = layers.length-1;

    //Skrur av alle lagene i WebMap'et
    for (i = 1; i < layers.length; i++) {
      map.getLayer(layers[i].id).hide();
    };
    //console.log(map.getLayer);
    //Setter det siste laget i listen (sisteLE) til å være oppstarts-swipelaget dersom ingen lag er blitt valgt før swipe-widgeten skrus på. 
    forrigeAar = map.getLayer(layers[sisteLE].id);
    $("#aarsspan").text((layers[sisteLE].title).slice(-4));
    $("#aarsspan3").text((layers[sisteLE].title).slice(-4));
    var forrige2 = (layers[sisteLE].title).slice(-4);
    console.log("SwipeLayer: " + layers[sisteLE].id);

    //Lager og starter opp Swipe-Widgeten med det siste elementet i laglisten som det aktive swipelaget. 
    
    swipeWidget = new LayerSwipe({
      type: "vertical",
      map: map,
      layers: [forrigeAar]
    }, "swipeDiv");
    
    swipeWidget.startup();
    swipeWidget.disable();

    
    //activates the layer that's going to be used with the LayerSwipe 
    function createSwipe(swipeAar) {
      console.log("Aktiverer swipe med lag: "+swipeAar);
      var swipeAarLag = map.getLayer(swipeAar);
      swipeAarLag.show();
      swipeWidget.layers=[ingenbilder, swipeAarLag];
    };
    


    //on click event for Swipe-button
    $("#SwipeButton").on("click", function() {
      ingenbilder.show();
      //If swiping is not active prior to clicking...
      if ($("#SwipeButton").attr("class") ==="inActive") {
        $("#SwipeButton").attr('class', 'Active')    
        map.getLayer(forrigeAar.id).hide();
        //ingenbilder.show();
        createSwipe(forrigeAar.id);
        swipeWidget.enable();
        $("#slettknapp").hide();
        $("#aarsdiv").show();
        $("#nonswipeaar").hide();
        console.log(swipeWidget.layers);
      }
      //Hvis swiping er aktiv: merk swipingen som inaktiv og disable swiping.
      else if ($("#SwipeButton").attr("class") ==="Active") {
        $("#SwipeButton").attr('class', 'inActive')
        swipeWidget.disable();
        //ingenbilder.hide();
        $("#slettknapp").show();
        $("#nonswipeaar").show();
      }
      console.log($("#SwipeButton").attr('class'));
    });


    //Funksjon for bytte av år
    function velgAar(nyttAar) {
      ingenbilder.show();
      //Dersom swiping er aktiv
      if ($("#SwipeButton").attr("class") ==="Active") {
        for (i = 1; i < layers.length; i++) {
          if (map.getLayer(layers[i].id).visible) {
            //Dersom laget er synlig, skru det av. 
            map.getLayer(layers[i].id).hide();
          }
          if (layers[i].title == nyttAar) {
            createSwipe(layers[i].id);
            console.log("Swipe-lag har blitt endret");
            //Lagrer laget som ble aktivert her for å senere kunne vite hvilket lag som ble aktivert sist 
            //slik at når swiping skrus på igjen er det det samme laget som blir skrudd på som sist. 
            forrigeAar = map.getLayer(layers[i].id);
            $("#aarsspan").text((layers[i].title).slice(-4));
            $("#aarsspan3").text((layers[i].title).slice(-4));
            $("#aarsdiv").show();
            //$("#nonswipeaar").show();
          }
        }
      }
      //Dersom swipingen ikke er slått på...
      else if ($("#SwipeButton").attr("class") ==="inActive") {
          //Sjekker om det er noen aktive lag
          for (i = 1; i < layers.length; i++) {
            if (map.getLayer(layers[i].id).visible) {
              //Dersom laget er synlig, skru det av. 
              console.log(layers[i].id);
              map.getLayer(layers[i].id).hide();
            }
            //Skrur på laget som matcher med identifikatoren til elementet som ble trykket på i drop-up menyen. 
            if (layers[i].title == nyttAar) {
              map.getLayer(layers[i].id).show();
              //Lagre laget som nettopp ble skrudd på til variabel. 
              forrigeAar = map.getLayer(layers[i].id);
              $("#aarsspan").text((layers[i].title).slice(-4));
              $("#aarsspan3").text((layers[i].title).slice(-4));
              $("#aarsdiv").show();
              $("#nonswipeaar").show();
            }
          };
          $("#slettknapp").show();
      }
    };

    //Starter løkken på 1 og ikke 0 for å hoppe over det første laget i listen "layers" som er labels fra FKB4 WMS.
    for (i = 1; i < layers.length; i++) {
      var tittel = layers[i].title;
      //Legg til LI items i UL med riktig formattert årstalls-navn
      $("#ulScroll").append($("<li>").text(String(tittel.slice(-4))).attr("id", "nr"+i).attr("navn", tittel).addClass("clickAar"));
      //Legger til en bootstrap-divider som skiller liste items fra hverandre
      $("#nr"+String(i)).append($("<div>").attr("class", "divider"));
    };
    

    /****************  Legger til on-click events på liste-items **************/
    $("ul").on("click", "li", function(event) {
      //event.preventDefault();
      velgAar( $(this).attr("navn") );
    });



    //fjerner det synlige laget når "Fjerne"-knappen trykkes på. 
    $("#slettknapp").on('click', function () {
      map.getLayer(forrigeAar.id).hide();
      ingenbilder.hide();
      $("#slettknapp").hide();
      $("#aarsdiv").hide();
      $("#nonswipeaar").hide();
    });

    //Home knappen panorerer til lagret oppstartposisjon for WebMap 
    var home = new HomeButton({
      map: map
    }, "HomeButton");
    home.startup();

    var search = new Search({
        map: map,
        enableInfoWindow: false,
        enableButtonMode: true,
        expanded: false
     }, "search");
     search.startup();

    $(".esriControlsBR").hide();
    $(".esriAttributionLastItem").hide();

    $(".handleContainer").append("<div id='aarsdiv'> </div>");
    $("#aarsdiv").append("<span id='aarsspan'>"+forrige2+"</span>");

    $(".handleContainer").append("<div id='aarsdiv2'> </div>");
    $("#aarsdiv2").append("<span id='aarsspan2'>2015</span>");


  });

});